from brancharchitect.distances import collect_splits
from brancharchitect.tree import Node
from brancharchitect.newick_parser import parse_newick
from typing import List, Dict, Tuple


def incorporate_split_counts(split_list: List[Tuple[int]], number_of_splits: dict[Tuple[int],dict]):
    for split in split_list:
        if split in number_of_splits:
            number_of_splits[split]['count'] += 1
        else:
            number_of_splits[split] = {'count': 1}

def collect_count_of_splits(list_of_trees: List[Node]) -> Dict[tuple[int], int]:
    number_of_splits = {}
    
    for tree in list_of_trees:        
        
        split_list = []
        
        collect_splits(tree, split_list)            
        incorporate_split_counts(split_list, number_of_splits)

    for split in number_of_splits.keys():
        number_of_splits[split]['occurrence'] = number_of_splits[split]['count'] / len(list_of_trees)
    
    return number_of_splits


def create_star_tree(tree_order: List[int])-> Node:
    star_tree = Node()    
    star_tree.split_indices = tree_order
    star_tree.name = tree_order
    for taxon_indices in tree_order:
        new_node = Node()
        new_node.name = taxon_indices
        new_node.split_indices = taxon_indices
        new_node.length = 1
        star_tree.children.append(new_node)                
    return star_tree


def filter_by_fifty(splits: Dict[Tuple[int], Dict[str, float]], number_of_taxa: int) -> List[Tuple[int]]:
    # List to store splits with occurrence over 50%
    over_fifty_split = []
    # Filter splits with occurrence over 50%
    for split in splits:
        if splits[split]['occurrence'] > 0.5 and len(split) > 1 and number_of_taxa != len(split):
            over_fifty_split.append(split)
    # Sort the splits by the size of their tuples
    over_fifty_split.sort(key=lambda x: len(x))    
    return over_fifty_split


def create_consensus_tree(tree_order: List[int], number_of_splits: List[int]) -> Node:
    start_tree = create_star_tree(tree_order)    
    over_fifty_splits = filter_by_fifty(number_of_splits, len(tree_order))    
    for split in over_fifty_splits:
        apply_split_in_tree(split, start_tree)
    print(start_tree.to_newick())

def apply_split_in_tree(split: Tuple[int], node: Node) -> Node:
    split_set = set(map(int, split))  # Convert split to set of strings
    
    # Check if split_set is a subset of node.split_indices
    if split_set.issubset(set(node.split_indices)) and split_set != set(node.split_indices):
        new_node = Node()
        new_node.split_indices = split_set
        new_node.split_indices = list(split_set)  # Convert back to list
        
        remaining_children = []

        # Reassign children
        for child in node.children:
            if child.split_indices in set(split_set):
                new_node.children.append(child)
            else:
                remaining_children.append(child)

        # Update original node's children and append new node
        node.children = remaining_children
        node.children.append(new_node)

    # Recursively apply to children
    for child in node.children:
        if child.children:
            apply_split_in_tree(split, child)

    return node

        
def test_consensus_tree():
    s = (
        '(A:1,(B:1,C:1):1);' 
         + 
         '(A:1,(B:1,C:1):1);'
         + 
         '(B:1,(A:1,C:1):1);'
         + 
         '(A:1,(B:1,C:1):1);'
    )    
    
    t1, t2, t3, t4  = parse_newick(s)    
    
    number_of_splits = collect_count_of_splits([t1,t2, t3, t4])    
    
    create_consensus_tree(tree_order=t1.split_indices, number_of_splits=number_of_splits)

if __name__ == '__main__':
    test_consensus_tree()    
