from brancharchitect.newick_parser import parse_newick
from brancharchitect.jumping_taxa import call_jumping_taxa
from brancharchitect.tree import Node
from typing import List, Optional, Tuple, Union

def test_jumping_taxa_1():
    s = ('(A:1,(B:1,C:1):1);' + '(B:1,(A:1,C:1):1);')
    
    t1, t2  = parse_newick(s)
    
    split_list_one = []
    split_list_two = []
        
    collect_splits(t1, split_list_one)
    collect_splits(t2, split_list_two)

    diff = calculate_relative_split_difference(split_list_one, split_list_two)
    

def collect_splits(node: Node, split_list: List):
    split_list += [node.split_indices]
    for child in node.children:
        collect_splits(child, split_list)

def calculate_split_difference(list_one: List, list_two: List) -> int:
    set_one = set(map(tuple, list_one))
    set_two = set(map(tuple, list_two))

    unique_to_one = set_one - set_two
    unique_to_two = set_two - set_one
    
    difference_count = len(unique_to_one) + len(unique_to_two)
        
    return difference_count

def calculate_relative_split_difference(list_one: List, list_two: List) -> float:
    set_one = set(map(tuple, list_one))
    set_two = set(map(tuple, list_two))

    unique_to_one = set_one - set_two
    unique_to_two = set_two - set_one
    
    total_unique_differences = len(unique_to_one) + len(unique_to_two)
    total_unique_splits = len(set_one | set_two)  # Union of both sets

    # To avoid division by zero
    if total_unique_splits == 0:
        return 0.0

    relative_difference = total_unique_differences / total_unique_splits
    
    return relative_difference


if __name__ == '__main__':
    test_jumping_taxa_1()    



